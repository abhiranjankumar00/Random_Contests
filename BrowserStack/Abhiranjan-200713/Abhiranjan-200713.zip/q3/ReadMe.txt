Client should have the same ip address as server. Otherwise please update ip address of server in Client.java.

It should be run on Ubuntu. And have firefox, chorme and opera browsers.

1. First start server.
2. Then start the client.
